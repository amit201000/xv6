#include"types.h"
#include"user.h"
#include"stat.h"
#include"fs.h"

int main(int argc, char* argv[])
{
	
	if (argc != 2)
	{
		printf(1,"Usage: NProcess 8\n");
		exit();
	}
	
	int n = atoi(argv[1])-1;
	int i=0;
	for (i=0; i< n; i++)
	{
		if(fork()==0)
		{
			printf(1, "Child Pid is %d\n", getpid());
			exit();
		}
	}

	for(i=0; i< n; i++)
	wait();
	printf(1,"Parent process, Pid is %d \n",getpid());	;

exit();
}
