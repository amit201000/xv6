#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include"fs.h"
int main(int argc, char *argv[])
{
cps();
exit();
}
